HAI TAC MINI — DU AN ANDROID

Day la du an Android fan-made, chua phai APK da bien dich. Ban game hien tai chay offline; chua co may chu online va chua co he thong ADMIN online an toan. Khong phai game goc va khong duoc cap phep boi chu so huu game goc.

TAO APK BANG DIEN THOAI QUA GITHUB ACTIONS (KHONG CAN MAY TINH)
1. Tren trinh duyet dien thoai, dang nhap GitHub va tao mot repository moi. Neu ban chua co tai khoan, hay nho phu huynh/nguoi lon tin cay ho tro tao va quan ly tai khoan.
2. Giai nen file ZIP nay tren dien thoai bang ung dung quan ly tep.
3. Tai repository GitHub, dung Add file > Upload files de tai len cac tep va thu muc ben trong HaiTacMiniAndroid (bao gom thu muc .github/workflows; neu khong thay thu muc an, can bat hien tep an trong ung dung giai nen). Bam Commit changes.
4. Mo tab Actions cua repository, chon workflow Build HaiTacMini APK, bam Run workflow neu no chua tu chay.
5. Cho workflow chay xong va hien dau xanh. Mo run vua hoan tat, tim phan Artifacts va tai HaiTacMini-debug-APK.zip.
6. Giai nen Artifact de lay app-debug.apk, sau do mo APK tren dien thoai de cai dat. Android co the yeu cau cho phep cai ung dung tu nguon nay.

Neu buoc build that bai, mo run do va doc log loi; APK chua duoc tao khi build that bai.

GIOI HAN HIEN TAI
- Game offline, chua co tai khoan online/may chu.
- Du lieu game hien chua duoc luu ben vung; dong ung dung co the lam mat tien trinh.
- Chua co bang ADMIN hoan chinh. Khong nen them chuc nang admin chi bang mot mat khau bi dong goi trong APK; quyen admin online phai duoc xac minh o may chu.
- Nhan vat va giao dien la ban fan-made, khong sao chep tai nguyen doc quyen cua game goc.
