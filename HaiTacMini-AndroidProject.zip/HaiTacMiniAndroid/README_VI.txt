HẢI TẶC MINI — DỰ ÁN ANDROID

Đây là dự án Android Studio chứa game fan-made chạy offline trong ứng dụng Android. Đây CHƯA phải file APK đã biên dịch, vì môi trường tạo file hiện tại không có Android SDK/Gradle để biên dịch APK.

CÁCH TẠO APK TRÊN MÁY TÍNH
1. Cài Android Studio từ trang chính thức: https://developer.android.com/studio
2. Giải nén HaiTacMini-AndroidProject.zip.
3. Trong Android Studio chọn Open và mở thư mục HaiTacMiniAndroid.
4. Chờ Gradle Sync hoàn tất (lần đầu cần internet để tải công cụ build).
5. Chọn Build > Build APK(s).
6. Khi build thành công, nhấn Locate trong thông báo; APK debug thường nằm tại app/build/outputs/apk/debug/app-debug.apk.
7. Chuyển APK sang điện thoại Android, mở file để cài. Android có thể yêu cầu cho phép cài ứng dụng từ nguồn này.

GAME
- Hoàn toàn offline sau khi cài.
- Đánh theo lượt, qua ải, nhận vàng/ngọc, chiêu mộ đồng đội, huấn luyện.
- Tiến trình hiện lưu trong phiên chạy; gỡ ứng dụng hoặc đóng app có thể làm mất dữ liệu.
- Nhân vật và giao diện là bản fan-made, không phải game gốc hay sản phẩm được cấp phép.
